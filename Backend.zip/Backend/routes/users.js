const express = require('express');
const router = express.Router();
const { getAllUsers, getUserById, updateUser, deleteUser, getAgents } = require('../Controllers/userController');

// Get all users
router.get('/', getAllUsers);

// Get a specific user by ID
router.get('/:id', getUserById);

// Update a user
router.put('/:id', updateUser);

// Delete a user
router.delete('/:id', deleteUser);

// Get all agents
router.get('/agents', getAgents);

module.exports = router;