module.exports = {

    HOST: "localhost",
    
    USER: "root",
    
    PASSWORD: "",
    
    DB: "mon_projet_db",
    
    dialect: "mysql",
    
    };